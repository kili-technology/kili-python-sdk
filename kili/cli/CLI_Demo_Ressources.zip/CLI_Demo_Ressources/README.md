## Work with Kili Command Line Interface (CLI)?


This folder is here to help you start with Kili’s CLI by providing: 
- a json_interface to create a project
- an « asset » folder with 40 assets to import to the created project
- a « label » folder with 10 labels to add to the imported assets
- a labels.csv file to demonstrate how to import with a .csv

Once in the current directory where all files are stored, you can run the following commands: 

▶ kili project create json_interface.json --title "Quality inspection" --input-type IMAGE
▶ kili project list --max 20
▶ project_id=$(kili project list --stdout-format "tsv" | grep -m1 "Quality inspection" | awk 'BEGIN {FS="\t"}; {print $2}')
▶ kili project member add --project-id $project_id --role REVIEWER $email_adress
▶ kili project member list $project_id
▶ kili project import --project-id $project_id assets
▶ kili project label --project-id $project_id --from-csv labels.csv
▶ kili project describe $project_id

